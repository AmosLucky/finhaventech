<?php
session_start();

require 'header.php';


$error = "";



// if(isset( $_SESSION['user'])){

//         echo " <script>
//         window.location.href='dashboard/index.php';
//         </script>";
//         }




        if(isset($_POST['login'])){

    $username = $_POST['email'];
    $password = $_POST['password'];

    $usernamev = mysqli_real_escape_string($con,$username);
    $passwordv = mysqli_real_escape_string($con,$password);

    $sql = "select * from members where email = '$usernamev'  && password = '$passwordv' || username = '$usernamev'  && password = '$passwordv' ";
    $result = mysqli_query($con,$sql) or die("cant select ".mysqli_error($con));
    $checkuser = mysqli_num_rows($result);
    if($checkuser == 1){
        while ($row = mysqli_fetch_array($result)) {
            $id = $row['id'];
            $isAdmin = $row['is_admin'];
             $is_suspended = $row['is_suspended'];
              $suspension_reason = $row['suspension_reason'];
               $is_deleted = $row['deleted'];


           if($is_deleted){
              $error = '<div class="alert alert-danger text-center">
              This account is suspended
              </div>';

           }else{
            /////////////////////////////NORMAL LOGIN//////////

              if($isAdmin){
                $_SESSION['admin_id'] = $row['id'];
             $_SESSION['admin'] =$row['username'];
              $id = $_SESSION['admin_id'];
                $_SESSION['admin'];
        


          //insert into transaction


       echo " <script>
        window.location.href='adminpanel';
        </script>";



    }else if($is_deleted){
         $error = "<div class='alert alert-danger text-center'>
        This account is suspended
              
              </div>";

    }else{
             
             $_SESSION['id'] = $row['id'];
             $_SESSION['user'] =$row['username'];
            // $_SESSION['balance'] =  $row['balance'];
              $_SESSION['email'] =$row['email'];
             $_SESSION['phonenumber'] =  $row['phonenumber'];
            $_SESSION['balance'] = $row['balance'];
             $_SESSION['state'] =$row['state'];
              $_SESSION['gender'] =$row['gender'];
               $is_comounded = $row['isCompounded'];
            
              $_SESSION['referree'] =  $row['referree'];
               $_SESSION['firstname'] =  $row['firstname'];
                $_SESSION['password'] =  $row['password'];
             $_SESSION['is_admin'] =  $row['is_admin'];
              $_SESSION['isCompounded'] =  $row['isCompounded'];
        echo " <script>
        window.location.href='user/';
        </script>";

    }
           }
            
        }

        // $id = $_SESSION['id'];
        // $_SESSION['balance'];
        // $user = $_SESSION['user'];
        // $_SESSION['email'];
        // $_SESSION['phonenumber'];
        // $_SESSION['state'];
        
        //   $_SESSION['firstname'];
        //   $_SESSION['referree'] ;
        //   $isAdmin = $_SESSION['is_admin'];


          //insert into transaction
         


       



        

    }
    //user more than two
    else{

        $error = '<div class="alert alert-danger text-center">We cant find your account please check your username or password</div>';

    }


}


// if(isset($_POST['login'])){
//   $login_name = $_POST['username'];
//   $login_psw = $_POST['password'];
// }
// else if(isset($_POST['signup'])){
//   $fname = $_POST['fname'];
//   $lname = $_POST['lname'];
//   $email = $_POST['email'];
//   $uname = $_POST['uname'];
//   $pass = $_POST['psw'];
//   $phone = $_POST['phone'];
// }

?>




    <main id="main" class="main-img">

        <section class="auth-section">
            <div class="auth-wrapper">
                <div class="auth-top-part">
                    <div style="height:200px"></div>
                    <!-- <a href="index" class="auth-logo">
                        <img class="img-fluid rounded sm-device-img text-align" src="asset/theme1/images/logo/logo.png"
                            width="100%" alt="pp">
                    </a> -->
                    <p class="mb-0"><span class="me-2">Dont Have An Account?</span> <a class="cmn-btn btn-sm"
                            href="register">Register</a></p>
                </div>
                <div class="auth-body-part">
                    <div class="auth-form-wrapper">
                        <h3 class="text-center mb-4">Login Your Account</h3>
                        <form  method="POST">
                             <?php echo  $error ?>
                            <div class="mb-3">
                                <label for="formGroupExampleInput">Email</label>
                                <input type="email" class="form-control" name="email" value="" id="email"
                                    placeholder="Enter Your Email">
                            </div>
                            <div class="mb-3">
                                <label for="formGroupExampleInput">Pasword</label>
                                <input type="password" class="form-control" name="password" id="password"
                                    placeholder="Enter Password">
                            </div>
                            <p class="text-end"><a href="password" class="color-change">Forget Password?</a>
                            </p>
                            <button class="cmn-btn w-100" type="submit" name="login"> Log In </button>
                        </form>
                    </div>
                </div>
                <div class="auth-footer-part">
                    <p class="text-center mb-0">
                        Copyright © 2015-2023 Beacon Empower. All Rights Reserved.
                    </p>
                </div>
            </div>
            <div class="auth-thumb-area">
                <div class="auth-thumb">
                    <img src="asset/theme1/images/frontendlogin/frontend_login_image.png" alt="image">
                </div>
            </div>
        </section>

    </main>

    <?php

require "footer.php";


?>




   
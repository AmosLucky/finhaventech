
<div style="position:fixed; bottom:0px; z-index: 1">
   <a href="https://wa.me/+16064610090">
     <img src="asset/theme1/images/whatsapp.png" alt="" width="100px">
   </a>
</div>
    
    <footer class="footer-section has-bg-img" style="z-index:-1">
        <div class="footer-top">
            <div class="map-el">
                <img src="asset/theme1/images/footer/6257ad9cc3fe61649913244.png" alt="">
            </div>
            <div class="container">
                <div class="row gy-5">
                    <div class="col-lg-4">
                        <div class="footer-box">
                            <a href="index">
                                <h3>
                                    <?= $company_name ?>
                                </h3>
                            </a>
                            <p><?= $company_name ?> is a premier technology-driven platform at the forefront of cryptocurrency, asset management, and risk management services. Founded on the principles of transparency, security, and innovation, <?= $company_name ?> has become a trusted destination for individuals and organizations seeking reliable solutions in the digital investment space.</p>
                           
                            <div class="footer-payment">
                                <h5>Payment Methods</h5>
                                <img src="asset/theme1/images/footer/payment-method.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6">
                        <div class="footer-box">
                            <h4 class="title">Useful Links</h4>
                            <ul class="footer-link-list">
                                <li> <a href="index">Home</a></li>
                                <li><a href="about">About</a></li>
                                <li><a href="contact">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="footer-box">
                            <h4 class="title">Our Services</h4>
                            <ul class="footer-link-list">
                                <li><a href="assets_management.php">Asset Management</a>
                                </li>
                                <li><a href="digital_asset_recovery.php">Digital Asset Recovery</a>
                                </li>
                                <li><a href="real_estate.php">Real Estate</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <div class="footer-box">
                            <h4 class="title">Location</h4>
                            <p>
                                USA<br>
                                <strong>Phone:</strong> <?= $company_phone ?><br>
                                <strong>Email:</strong> <?= $company_email ?><br>
                            </p>
                            <ul class="social-links">
                                <li>
                                    <a href="http://www.facebook.com/" target="_blank" class="twitter"><i
                                            class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.linkedin.com/" target="_blank" class="twitter"><i
                                            class="fab fa-linkedin-in"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.twitter.com/" target="_blank" class="twitter"><i
                                            class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.pinterest.com/" target="_blank" class="twitter"><i
                                            class="fab fa-pinterest-p"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <p class="text-center mb-0">
                    Copyright © 2015-2023 <?= $company_name ?>. All Rights Reserved.
                </p>
            </div>
        </div>

        <!-- Smartsupp Live Chat script -->
       
    </footer>



    <button type="button" class="cmn-btn btn-sm btn-floating" id="btn-back-to-top">
        <i class="fas fa-arrow-up text-light"></i>
    </button>

    <script src="asset/theme1/frontend/js/jquery.min.js"></script>
    <script src="asset/theme1/frontend/vendor/purecounter/purecounter.js"></script>
    <script src="asset/theme1/frontend/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="asset/theme1/frontend/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="asset/theme1/frontend/js/slick.min.js"></script>
    <script src="asset/theme1/frontend/vendor/php-email-form/validate.js"></script>
    <script src="asset/theme1/frontend/js/selectric.min.js"></script>
    <script src="asset/theme1/frontend/js/main.js"></script>
    <script src="asset/theme1/frontend/js/iziToast.min.js"></script>
    <script src="asset/theme1/frontend/js/jquery.uploadPreview.min.js"></script>

    <script>
        $(function () {
            'use strict'

            $('.balance').on('click', function () {
                const modal = $('#invest');
                modal.find('input[name=plan_id]').val($(this).data('plan').id);
                modal.modal('show')
            })
        })
    </script>
    <script>
        'use strict';
        $(document).ready(function () {
            $(document).on('click', '#calculate-btn', function () {

                let modal = $('#calculationModal');

                $('.selectplan').text('');
                $('.amount').text('');
                let id = $('#plan').val();
                let amount = $('#amount').val();
                var url = "index.php";
                url = url.replace(':id', id);
                $.ajax({
                    type: 'GET',
                    url: url,
                    data: {
                        amount: amount,
                        selectplan: id
                    },
                    success: (data) => {
                        if (data.message) {
                            iziToast.error({
                                message: data.message + ' ' + Number(data.amount).toFixed(2),
                                position: 'topRight',
                            });

                        } else {
                            $('#profit').html(data);
                            modal.modal('show');
                        }


                    },
                    error: (error) => {
                        if (typeof (error.responseJSON.errors.amount) !== "undefined") {
                            iziToast.error({
                                message: error.responseJSON.errors.amount,
                                position: 'topRight',
                            });
                        }
                        if (typeof (error.responseJSON.errors.selectplan) !== "undefined") {
                            iziToast.error({
                                message: error.responseJSON.errors.selectplan,
                                position: 'topRight',
                            });
                        }
                    }
                })
            });



        });
    </script>











    <script>
        'use strict'


        $(document).on('submit', '#subscribe', function (e) {
            e.preventDefault();
            const email = $('.subscribe-email').val();
            var url = "subscribe.html";
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    email: email,
                },
                success: (data) => {
                    iziToast.success({
                        message: data.message,
                        position: 'topRight',
                    });
                    $('.subscribe-email').val('');

                },
                error: (error) => {
                    if (typeof (error.responseJSON.errors.email) !== "undefined") {
                        iziToast.error({
                            message: error.responseJSON.errors.email,
                            position: 'topRight',
                        });
                    }

                }
            })

        });

        var url = "index.php";

        $(".changeLang").change(function () {
            if ($(this).val() == '') {
                return false;
            }
            window.location.href = url + "?lang=" + $(this).val();
        });
        //Get the button
        let mybutton = document.getElementById("btn-back-to-top");

        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function () {
            scrollFunction();
        };

        function scrollFunction() {
            if (
                document.body.scrollTop > 20 ||
                document.documentElement.scrollTop > 20
            ) {
                mybutton.style.display = "block";
            } else {
                mybutton.style.display = "none";
            }
        }
        // When the user clicks on the button, scroll to the top of the document
        mybutton.addEventListener("click", backToTop);

        function backToTop() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>

   
</body>



<!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container" style="position:fixed; bottom:0px">
  <div class="tradingview-widget-container__widget"></div>
  
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "proName": "FOREXCOM:SPXUSD",
      "title": "S&P 500 Index"
    },
    {
      "proName": "FOREXCOM:NSXUSD",
      "title": "US 100 Cash CFD"
    },
    {
      "proName": "FX_IDC:EURUSD",
      "title": "EUR to USD"
    },
    {
      "proName": "BITSTAMP:BTCUSD",
      "title": "Bitcoin"
    },
    {
      "proName": "BITSTAMP:ETHUSD",
      "title": "Ethereum"
    }
  ],
  "showSymbolLogo": true,
  "isTransparent": false,
  "displayMode": "adaptive",
  "colorTheme": "dark",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
</html>
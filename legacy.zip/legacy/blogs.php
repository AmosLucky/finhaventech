<?php

require "header.php";


?>
<main id="main" class="main-img">


    <section class="breadcrumbs" style="background-image: url(asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center text-capitalize">
                <h2>Blog</h2>
                <ol>
                    <li><a href="index">Home</a></li>
                    <li>Blog</li>
                </ol>
            </div>

        </div>
    </section>



    <section class="s-pt-100 s-pb-100">
        <div class="container">
            <div class="row gy-4">

                <div class="col-md-6 col-lg-4">
                    <div class="blog-box">
                        <div class="blog-box-thumb">
                            <img src="asset/theme1/images/blog/624d61e797df71649238503.jpg" alt="image">
                        </div>
                        <div class="blog-box-content">
                            <!-- <span class="blog-category">Bitcoin</span> -->
                            <h3 class="title"><a href="blog_1.php">
                                Major Funding Secured: Introducing  Raises $10 Million in Series A Round
                               </a>
                            </h3>
                            <ul class="blog-meta">
                                <li><i class="fas fa-clock"></i> 2 moths ago</li>
                                <li><i class="fas fa-comment"></i> 569 Comments</li>
                            </ul>
                            <p class="mb-0 mt-3">
                                
                                    This strategic funding round, led by prominent global investors, will accelerate our product development, enhance platform security, and support our mission to bring smarter investing solutions to users around the world.
                                
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="blog-box">
                        <div class="blog-box-thumb">
                            <img src="asset/theme1/images/blog/624d62471f5b51649238599.jpg" alt="image">
                        </div>
                        <div class="blog-box-content">
                            <!-- <span class="blog-category">Crypto</span> -->
                            <h3 class="title"><a href="blog_2.php">
                                
                                    Introducing Multi-Asset Support on Introducing                                     
                                </a>
                            </h3>
                            <ul class="blog-meta">
                                <li><i class="fas fa-clock"></i> 3 months ago</li>
                                <li><i class="fas fa-comment"></i> 465 Comments</li>
                            </ul>
                            <p class="mb-0 mt-3">
                               
                                    Our platform now allows users to manage cryptocurrencies, stocks, and other digital assets in one seamless interface — simplifying portfolio management and maximizing convenience like never before.
                                
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="blog-box">
                        <div class="blog-box-thumb">
                            <img src="asset/theme1/images/blog/624d626242e021649238626.jpg" alt="image">
                        </div>
                        <div class="blog-box-content">
                            <!-- <span class="blog-category">Coinbase</span> -->
                            <h3 class="title"><a href="blog_3.php">
                               
                                    Introducing  Launches New Risk Management Dashboard
                                   
                                </a>
                            </h3>
                            <ul class="blog-meta">
                                <li><i class="fas fa-clock"></i> 4 monthd ago</li>
                                <li><i class="fas fa-comment"></i> 568 Comments</li>
                            </ul>
                            <p class="mb-0 mt-3">
                               
                                    Designed to help users make smarter decisions, the new dashboard offers real-time market analytics, automated alerts, and customizable risk profiles for better control and transparency in every investment.
                            
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>

</main>
<?php

require "footer.php";


?>
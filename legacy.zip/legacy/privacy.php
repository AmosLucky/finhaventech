<?php

require "header.php";

?>
    <main id="main" class="main-img">

        <section class="breadcrumbs" style="background-image: url(../asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
            <div class="container">
                <div class="d-flex justify-content-between align-items-center text-capitalize">
                    <h2>Privacy Policy</h2>
                    <ol>
                        <li><a href="../index.html">Home</a></li>
                        <li>Privacy Policy</li>
                    </ol>
                </div>

            </div>
        </section>

        <!-- ======= Portfolio Section ======= -->
        <section>
            <div class="container" data-aos="fade-up">
                <div class="col-md-12">
                    <div class="row ">
                        <div class="col-md-12">
                            <div class="bg-dark card">
                                <div class="invest-top">
                                    <h4 class="text-center"><b>Privacy Policy</b></h4>
                                </div>

                                 <!-- About Section One Area Start -->
    <section class="fina-about-section-one-area section_100">
        <div class="container">
            <div class="row">
              
                <div class="col-md-12">
                    <div class="about-section-one-right">
                        <div class="container">
    <h1>Privacy Policy</h1>
    <p><strong>Effective Date:</strong> <?= date("F d, Y") ?></p>

    <p>Welcome to <strong><?= $company_name ?></strong>. We respect your privacy and are committed to protecting your personal and financial information. This Privacy Policy describes how <strong><?= $company_name ?></strong> (“we,” “our,” or “us”) collects, uses, stores, and discloses your information when you use our website and services related to asset management and risk management.</p>

    <h2>1. Information We Collect</h2>
    <h3>a. Personal Information</h3>
    <ul>
      <li>Full name</li>
      <li>Email address</li>
      <li>Contact number</li>
      <li>Government-issued identification</li>
      <li>Financial and investment information</li>
    </ul>

    <h3>b. Business/Client Data</h3>
    <ul>
      <li>Company name and profile</li>
      <li>Asset details</li>
      <li>Risk tolerance and investment preferences</li>
    </ul>

    <h3>c. Automatically Collected Information</h3>
    <ul>
      <li>IP address</li>
      <li>Browser and device details</li>
      <li>Site usage statistics</li>
      <li>Cookies and analytics data</li>
    </ul>

    <h2>2. How We Use Your Information</h2>
    <ul>
      <li>To deliver and optimize investment and risk services</li>
      <li>For financial analysis and reporting</li>
      <li>For legal compliance (e.g., KYC/AML)</li>
      <li>To communicate updates and offers</li>
      <li>To protect against fraud and enhance security</li>
    </ul>

    <h2>3. Legal Basis for Processing</h2>
    <p>We process your data under applicable legal bases including contractual necessity, compliance obligations, legitimate interests, and your consent where applicable.</p>

    <h2>4. Information Sharing</h2>
    <p>We may share your data with regulators, financial institutions, trusted service providers, legal advisors, or others as required by law or with your consent.</p>

    <h2>5. Data Security</h2>
    <p>We implement industry-standard safeguards including encryption, firewalls, and regular security audits. However, no method of transmission over the internet is 100% secure.</p>

    <h2>6. Data Retention</h2>
    <p>We retain your information only as long as necessary for service delivery and legal compliance.</p>

    <h2>7. Your Rights</h2>
    <p>Depending on your location, you may have rights to access, correct, delete, or object to the processing of your personal data. To exercise your rights, email us at <a href="mailto:privacy@<?= strtolower($company_name) ?>.com">privacy@<?= strtolower($company_name) ?>.com</a>.</p>

    <h2>8. Cookies</h2>
    <p>We use cookies for session management, analytics, and personalization. You can control cookie settings via your browser preferences.</p>

    <h2>9. International Transfers</h2>
    <p>Your data may be processed in countries outside your own. We ensure appropriate protections are in place for international data transfers.</p>

    <h2>10. Children’s Privacy</h2>
    <p>Our services are not intended for children under 18. We do not knowingly collect data from minors.</p>

    <h2>11. Policy Updates</h2>
    <p>We may revise this policy periodically. We encourage you to review this page for any updates, which are effective upon posting.</p>

                        
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- End Portfolio Section -->

    </main>

    <?php

    require "foooter.php";

    ?>

<?php

require "header.php";


?>
    <main id="main" class="main-img">




        <section class="banner-section has-bg-img"
            style="background-image: url(asset/theme1/images/banner/63148233390f51662288435.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-xxl-6 col-xl-7 col-lg-8 text-lg-start text-center">
                        <h2 class="banner-title">Empower Your Strategy With The Most Reliable Asset And Risk Management Platform For Smart, Secure Decision-Making.</h2>
                        <p>The Most Trusted Cryptocurrency Platform and Asset Management</p>
                        <div class="banner-btn-group justify-content-lg-start justify-content-center mt-4">
                            <a href="plan" class="cmn-btn">Get Started</a>
                            <a href="contact" class="border-btn">Know More</a>
                        </div>
                        <h5 class="mt-5">Trusted By More Than 45,000+ Users</h5>
                        <div class="row mt-4 overview-wrapper">
                            <div class="col-lg-3 col-4">
                                <div class="overview-box">
                                    <div class="overview-box-amount">28K</div>
                                    <p>Total Investors</p>
                                </div>
                            </div>
                            <div class="col-lg-3 col-4">
                                <div class="overview-box">
                                    <div class="overview-box-amount">98M</div>
                                    <p>Total Deposit</p>
                                </div>
                            </div>
                            <div class="col-lg-3 col-4">
                                <div class="overview-box">
                                    <div class="overview-box-amount">57M</div>
                                    <p>Total Withdraw</p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>


        <div class="calculate-area">
            <div class="calculator"><img src="asset/theme1/images/elements/budget.png" alt="image"></div>
            <div class="shape-1"><img src="asset/theme1/images/elements/cal-1.png" alt="image"></div>
            <div class="shape-2"><img src="asset/theme1/images/elements/cal-2.png" alt="image"></div>
            <div class="shape-3"><img src="asset/theme1/images/elements/cal-3.png" alt="image"></div>
            <div class="shape-4"><img src="asset/theme1/images/elements/cal-4.png" alt="image"></div>

            <div class="container">
                <div class="row gy-4 align-items-end">
                    <div class="col-lg-4 col-md-6">
                        <label class="mbl-h">Amount</label>
                        <input type="text" class="form-control" name="amount" id="amount" placeholder="Enter Amount">
                    </div>
                    <div class="col-lg-5 col-md-6">
                        <label class="mbl-h"> Plans</label>
                        <select class="form-select" name="selectplan" id="plan">
                            <option selected disabled class="text-secondary">Select A Plan</option>
                            <option value="7">Turbo 🔥</option>
                            <option value="8">Gold 🪙 plan</option>
                            <option value="9">Silver 🥈 plans</option>
                            <option value="10">Beginner plan1</option>
                            <option value="11">Beginner plan 2</option>
                        </select>
                    </div>
                    <div class="col-lg-3">
                        <a href="#" id="" class="cmn-btn w-100"> Calculate Earning</a>
                    </div>
                </div>
            </div>
        </div>
        <section class="about-section s-pt-100 s-pb-100 section-bg">
            <div class="shape-el">
                <img src="asset/theme1/images/about/flow-chart.png" alt="image">
            </div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-thumb">
                            <div class="about-thumb-inner">
                                <img src="asset/theme1/images/about/6257a3187a4ca1649910552.png" alt="image">
                                <div class="about-thumb-line about-thumb-line-one"></div>
                                <div class="about-thumb-line about-thumb-line-two"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <h2 class="section-title">About Us</h2>
                        <p class="text-white text-justifys descripton-root">
                        <p style="font-size:16px;font-family:Rubik, sans-serif;"><?= $company_name ?> is a premier technology-driven platform at the forefront of cryptocurrency, asset management, and risk management services. Founded on the principles of transparency, security, and innovation, <?= $company_name ?> has become a trusted destination for individuals and organizations seeking reliable solutions in the digital investment space.</p>
                        <p style="font-size:16px;font-family:Rubik, sans-serif;">
                            "Securing this funding is a major endorsement of the work we've done and the ambitious goals we’ve set," said the company. "We’re excited to take <?= $company_name ?> to the next level and continue delivering exceptional value to our customers and partners."
                        </p>
                            
                        <p style="font-size:16px;font-family:Rubik, sans-serif;">
                            With a user-friendly interface and state-of-the-art infrastructure, <?= $company_name ?> offers a seamless experience for buying, selling, and managing cryptocurrencies, while also providing powerful tools for portfolio diversification, asset tracking, and strategic risk mitigation. The platform is designed to serve both newcomers and experienced investors by combining intuitive design with advanced analytics and real-time insights.
                        </p>
                        <span style="font-family:Rubik, sans-serif;font-size:16px;">We try to learn from our users and
                            other competitors. We love your feedback. Just</span><span
                            style="font-family:Rubik, sans-serif;font-size:16px;"> </span><a
                            href="contact">write us</a><span
                            style="font-family:Rubik, sans-serif;font-size:16px;"> </span><span
                            style="font-family:Rubik, sans-serif;font-size:16px;">a line, we read all your
                            feedback.</span><span
                            style="color:rgb(0,0,0);font-family:'Open Sans', Arial, sans-serif;font-size:14px;text-align:justify;">.</span>
                        </p>
                        <a href="about" class="cmn-btn">Learn More</a>
                    </div>
                </div>

            </div>
        </section>
        <section class="s-pt-100 s-pb-100">
            <div class="container">

                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">Why Choose US</h2>
                        </div>
                    </div>
                </div>

                <div class="row gy-4 feature-wrapper">
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-box">
                            <div class="icon">
                                <div class="icon-line">
                                    <span class="icon-line-dot icon-line-dot-one"></span>
                                    <span class="icon-line-dot icon-line-dot-two"></span>
                                    <span class="icon-line-dot icon-line-dot-three"></span>
                                </div>
                                <div class="icon-inner">

                                    <i class="far fa-compass"></i>
                                </div>
                            </div>
                            <div class="content">
                                <h3 class="title mb-3">Registered Company</h3>
                                <p class="mb-0"><?= $company_name ?> is a fully registered and legally compliant platform, offering transparency and peace of mind to all our users worldwide.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-box">
                            <div class="icon">
                                <div class="icon-line">
                                    <span class="icon-line-dot icon-line-dot-one"></span>
                                    <span class="icon-line-dot icon-line-dot-two"></span>
                                    <span class="icon-line-dot icon-line-dot-three"></span>
                                </div>
                                <div class="icon-inner">

                                    <i class="fas fa-file-export"></i>
                                </div>
                            </div>
                            <div class="content">
                                <h3 class="title mb-3">Trusted Reputation</h3>
                                <p class="mb-0">
                                    With a growing global user base and a strong track record of reliability, <?= $company_name ?> is recognized as one of the most trusted platforms in the cryptocurrency and asset management space.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-box">
                            <div class="icon">
                                <div class="icon-line">
                                    <span class="icon-line-dot icon-line-dot-one"></span>
                                    <span class="icon-line-dot icon-line-dot-two"></span>
                                    <span class="icon-line-dot icon-line-dot-three"></span>
                                </div>
                                <div class="icon-inner">

                                    <i class="fas fa-user-secret"></i>
                                </div>
                            </div>
                            <div class="content">
                                <h3 class="title mb-3">Advanced Security Measures</h3>
                                <p class="mb-0">
                                    We prioritize the safety of your data and assets with multi-layered encryption, two-factor authentication (2FA), and round-the-clock monitoring.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-box">
                            <div class="icon">
                                <div class="icon-line">
                                    <span class="icon-line-dot icon-line-dot-one"></span>
                                    <span class="icon-line-dot icon-line-dot-two"></span>
                                    <span class="icon-line-dot icon-line-dot-three"></span>
                                </div>
                                <div class="icon-inner">

                                    <i class="fas fa-money-bill-wave"></i>
                                </div>
                            </div>
                            <div class="content">
                                <h3 class="title mb-3">Comprehensive Asset & Risk Management</h3>
                                <p class="mb-0">From diversified portfolio tools to risk control strategies, our platform is designed to help you manage your investments smartly and securely.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-box">
                            <div class="icon">
                                <div class="icon-line">
                                    <span class="icon-line-dot icon-line-dot-one"></span>
                                    <span class="icon-line-dot icon-line-dot-two"></span>
                                    <span class="icon-line-dot icon-line-dot-three"></span>
                                </div>
                                <div class="icon-inner">

                                    <i class="fas fa-registered"></i>
                                </div>
                            </div>
                            <div class="content">
                                <h3 class="title mb-3">User-Friendly Experience</h3>
                                <p class="mb-0">Our intuitive interface makes it easy for both beginners and seasoned investors to navigate, track, and optimize their portfolios with ease.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-box">
                            <div class="icon">
                                <div class="icon-line">
                                    <span class="icon-line-dot icon-line-dot-one"></span>
                                    <span class="icon-line-dot icon-line-dot-two"></span>
                                    <span class="icon-line-dot icon-line-dot-three"></span>
                                </div>
                                <div class="icon-inner">

                                    <i class="fas fa-fingerprint"></i>
                                </div>
                            </div>
                            <div class="content">
                                <h3 class="title mb-3">24/7 Customer Support</h3>
                                <p class="mb-0">Our dedicated support team is always available to assist you, ensuring a smooth and responsive experience at every stage of your journey.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- End Services Section -->
        <section class="s-pt-100 s-pb-100">
        <div class="container">
             <div class="row gy-4">

                   <?php

                                           $sql = "SELECT * from investment_plans where deleted = '0' order by id desc ";
                                    $sn = 1;
                                   $result = mysqli_query($con,$sql) or die("cant select members ".mysqli_error($con));
                                   while ($row = mysqli_fetch_array($result)) {
                                      $id = $row['id'];
              $min =  $row['min_deposite'];
               $max =  $row['max_deposite'];
               $profit =  $row['daily_profit'];
                $name =  $row['name'];
                $capital_after =  $row['capital_after'];
                 $profit_after =  $row['profit_after'];
                 $referal_bonus =  $row['referal_bonus'];
                  $reg_date =  $row['reg_date'];
                  $daily_profit =  $row['daily_profit'];

                                            ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="invest-plan">
                            <div class="invest-plan-shape"></div>
                            <div class="invest-plan-top">
                                <h4 class="invest-plan-name"><?= $name ?></h4>
                                <h5 class="invest-plan-amount"><?= $daily_profit ?>% daily
                                </h5>
                                <p class="mb-0">After 24hours</p>
                            </div>

                            <div class="invest-plan-middle">
                                <h5 class="invest-plan-min-max">
                                    Min
                                   <?= number_format($min) ?> USD
                                    <p class="mb-0">-</p>
                                    Max
                                     <?php if($max == "UNLIMITED"){
                                        echo $max;
                                    }else{ 
                                       echo number_format($max);
                                    }  ?> USD
                                </h5>
                                <ul class="invest-plan-features">
                                    <li>
                                        Daily Profit: <?= $daily_profit ?>%

                                    </li>
                                     <li>
                                       Referral Bonus: <?= $referal_bonus ?>%

                                    </li>
                                     <li>
                                        Duration: 24Hour(s)

                                    </li>



                                    <li>Capital Back YES</li>
                                </ul>
                            </div>
                            <div class="invest-plan-action mt-3">
                                <a class="cmn-btn w-100 mb-3" href="login">Invest Now</a>


                            </div>
                        </div>
                    </div>

                    <?php } ?>


                    
                    
                    
                   
                </div>
        </div>
    </section>
        <div class="modal fade" id="invest" tabindex="-1" role="dialog" aria-labelledby="modelTitleId"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form action="" method="post">
                    <input type="hidden" name="_token" value="Uh03H5wcscZvULvvY2s5dmwfC24b9Rz1Tie3M2t3">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Invest Now</h5>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="container-fluid">
                                <div class="form-group">
                                    <label for="">Invest Amount</label>
                                    <input type="text" name="amount" class="form-control">
                                    <input type="hidden" name="plan_id" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn cmn-btn">Invest Now</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <section class="s-pt-100 s-pb-100">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">How It Work</h2>
                        </div>
                    </div>
                </div>

                <div class="row gy-5 work-wrapper">
                    <div class="col-lg-4">
                        <div class="work-box">
                            <div class="icon">
                                <i class="far fa-user"></i>
                            </div>
                            <div class="content">
                                <h3 class="title">Create Your Account</h3>
                                <p>Sign up quickly with your email and verify your identity to access all features of <?= $company_name ?> securely.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="work-box">
                            <div class="icon">
                                <i class="far fa-user"></i>
                            </div>
                            <div class="content">
                                <h3 class="title">Fund & Manage Your Portfolio</h3>
                                <p>Deposit funds, buy cryptocurrencies, and explore asset management tools to build and monitor your investment strategy.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="work-box">
                            <div class="icon">
                                <i class="far fa-user"></i>
                            </div>
                            <div class="content">
                                <h3 class="title">Track, Grow, and Withdraw</h3>
                                <p>Watch your assets grow with real-time insights, smart risk tools, and easy withdrawal options—anytime, anywhere.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="s-pt-100 s-pb-100 section-bg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">FAQ</h2>
                        </div>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-1">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse1" aria-expanded="false" aria-controls="collapseSix">
                                       Is <?= $company_name ?> a Registered Company?
                                    </button>
                                </h2>
                                <div id="collapse1" class="accordion-collapse collapse" aria-labelledby="heading-1"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            Yes, <?= $company_name ?> is a fully registered and compliant company, operating under the legal regulations of the jurisdictions we serve. Your trust and security are our top priorities.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-2">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapseSix">
                                        How Do I Create an Account?
                                    </button>
                                </h2>
                                <div id="collapse2" class="accordion-collapse collapse" aria-labelledby="heading-2"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            Creating an account is simple. Click the “Sign Up” button, provide your basic details, verify your email, and complete identity verification to get started.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-3">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse3" aria-expanded="false" aria-controls="collapseSix">
                                        What Payment Methods Are Supported?
                                    </button>
                                </h2>
                                <div id="collapse3" class="accordion-collapse collapse" aria-labelledby="heading-3"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            We support a variety of payment methods including bank transfers, credit/debit cards, and selected cryptocurrencies for deposits and withdrawals.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-4">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse4" aria-expanded="false" aria-controls="collapseSix">
                                        Is My Information and Investment Safe?
                                    </button>
                                </h2>
                                <div id="collapse4" class="accordion-collapse collapse" aria-labelledby="heading-4"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            Absolutely. <?= $company_name ?> uses advanced encryption, two-factor authentication, and secure servers to protect your personal and financial information.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-5">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse5" aria-expanded="false" aria-controls="collapseSix">
                                        Can I Withdraw My Funds Anytime?
                                    </button>
                                </h2>
                                <div id="collapse5" class="accordion-collapse collapse" aria-labelledby="heading-5"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            Yes, you can request withdrawals at any time. We process most withdrawal requests quickly and securely, depending on the payment method chosen.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-6">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse6" aria-expanded="false" aria-controls="collapseSix">
                                        Do I Need Experience to Use <?= $company_name ?>?
                                    </button>
                                </h2>
                                <div id="collapse6" class="accordion-collapse collapse" aria-labelledby="heading-6"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            No prior experience is needed. Our platform is designed for both beginners and professionals, offering user-friendly tools and 24/7 customer support to guide you.


                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <section class="s-pt-100 s-pb-100 d-none">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">Recent Transaction</h2>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <ul class="nav nav-pills has-two mb-4" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                                        aria-selected="true">Latest Invests</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-profile" type="button" role="tab"
                                        aria-controls="pills-profile" aria-selected="false">Latest Withdraws</button>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane table-content fade show active" id="pills-home" role="tabpanel"
                                aria-labelledby="pills-home-tab">
                                <table class="table cmn-table style-separate">
                                    <thead>
                                        <tr class="bg-yellow">
                                            <th scope="col">Username</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Gateway</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td data-caption="Username">Bigdaddy1</td>
                                            <td data-caption="Date">
                                                2025-02-16</td>
                                            <td data-caption="Amount">
                                                50,000.00 USD</td>
                                            <td data-caption="Gateway">Deposit
                                            </td>
                                        </tr>
                                        
                                        
                                       
                                    </tbody>
                                </table>
                            </div>

                            <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                aria-labelledby="pills-profile-tab">
                                <table class="table cmn-table style-separate">
                                    <thead>
                                        <tr class="bg-yellow">
                                            <th scope="col">Name</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Gateway</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td data-caption="Name">williams.smith78</td>
                                            <td data-caption="Date">
                                                2023-09-27</td>
                                            <td data-caption="Amount">
                                                1,500.00 USD
                                            </td>
                                            <td data-caption="Gateway">CoinPayments BTC
                                            </td>
                                        </tr>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section><!-- End Transaction Section -->
        <!-- investor section start -->
        <section id="investor" class="investor-section s-pt-100 s-pb-100 section-bg">
            <div class="investor-el">
                <img src="asset/theme1/images/investor/6319cfe9d77421662636009.png" alt="image">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xxl-4 col-lg-5 text-md-start text-center">
                        <div class="section-header">
                            <h2 class="section-title">Top Investor</h2>
                        </div>
                    </div>
                </div>
                <div class="investor-slider wow fadeInUp" data-wow-delay="0.3s" data-wow-duration="0.5s">
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb"
                                style="background-image: url('asset/theme1/images/user/64e346d5813761692616405.jpg');">
                            </div>
                            <div class="content">
                                <h4>Anderson Capital Group</h4>
                                <p>Invest Amount <span class="site-color">$523,000 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb"
                                style="background-image: url('asset/theme1/images/user/64dd068b780971692206731.jpg');">
                            </div>
                            <div class="content">
                                <h4>NovaTech Ventures</h4>
                                <p>Invest Amount <span class="site-color">115,310.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb" style="background-image: url('asset/theme1/images/placeholder.png');">
                            </div>
                            <div class="content">
                                <h4>Lighthouse Global Holdings</h4>
                                <p>Invest Amount <span class="site-color">120,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb" style="background-image: url('asset/theme1/images/placeholder.png');">
                            </div>
                            <div class="content">
                                <h4>Orion Digital Partners</h4>
                                <p>Invest Amount <span class="site-color">501,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb"
                                style="background-image: url('asset/theme1/images/user/6492f405d87d41687352325.jpg');">
                            </div>
                            <div class="content">
                                <h4>Sánchez Ortiz</h4>
                                <p>Invest Amount <span class="site-color">37,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb"
                                style="background-image: url('asset/theme1/images/user/64e0ad43b37231692446019.jpg');">
                            </div>
                            <div class="content">
                                <h4>Shahin Abdollahbpour</h4>
                                <p>Invest Amount <span class="site-color">29,800.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb"
                                style="background-image: url('asset/theme1/images/user/647225c78b5551685202375.jpg');">
                            </div>
                            <div class="content">
                                <h4>Rick Sanchez</h4>
                                <p>Invest Amount <span class="site-color">28,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb" style="background-image: url('asset/theme1/images/placeholder.png');">
                            </div>
                            <div class="content">
                                <h4>Mcheae Michael</h4>
                                <p>Invest Amount <span class="site-color">10,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb" style="background-image: url('asset/theme1/images/placeholder.png');">
                            </div>
                            <div class="content">
                                <h4>Angelina Capaci</h4>
                                <p>Invest Amount <span class="site-color">6,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb"
                                style="background-image: url('asset/theme1/images/user/65c7020f2785b1707541007.png');">
                            </div>
                            <div class="content">
                                <h4>Arton, Michael</h4>
                                <p>Invest Amount <span class="site-color">6,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb" style="background-image: url('asset/theme1/images/placeholder.png');">
                            </div>
                            <div class="content">
                                <h4>William Smith</h4>
                                <p>Invest Amount <span class="site-color">5,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb"
                                style="background-image: url('asset/theme1/images/user/64bc70e9d1c9c1690071273.jpg');">
                            </div>
                            <div class="content">
                                <h4>Roxanne Citizen</h4>
                                <p>Invest Amount <span class="site-color">5,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb"
                                style="background-image: url('asset/theme1/images/user/6474bae31c0881685371619.jpg');">
                            </div>
                            <div class="content">
                                <h4>Louis Anthony</h4>
                                <p>Invest Amount <span class="site-color">5,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb" style="background-image: url('asset/theme1/images/placeholder.png');">
                            </div>
                            <div class="content">
                                <h4>Fred Peterson</h4>
                                <p>Invest Amount <span class="site-color">5,000.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb" style="background-image: url('asset/theme1/images/placeholder.png');">
                            </div>
                            <div class="content">
                                <h4>Sanchez Nathaniel</h4>
                                <p>Invest Amount <span class="site-color">4,500.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb" style="background-image: url('asset/theme1/images/placeholder.png');">
                            </div>
                            <div class="content">
                                <h4>Zakeeya Thompson</h4>
                                <p>Invest Amount <span class="site-color">200.00 USD</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="investor-item">
                            <div class="thumb" style="background-image: url('asset/theme1/images/placeholder.png');">
                            </div>
                            <div class="content">
                                <h4>Valerie Sanchez</h4>
                                <p>Invest Amount <span class="site-color">100.00 USD</span></p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- investor section end -->
        <section class="s-pt-100 s-pb-100 section-bg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">What Our Clients Say</h2>
                        </div>
                    </div>
                </div>

                <div class="testimonial-slider">
                    <!-- <div class="single-slide">
                        <div class="testimonial-box">
                            <div class="content">
                                <p>
                                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                   “<?= $company_name ?> has completely changed how I manage my digital assets. The platform is secure, easy to use, and their support team is always there when I need help.”
                                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                </p>
                            </div>
                            <div class="client">
                                <div class="thumb">
                                    <img src="asset/theme1/images/testimonial/61fd4cd9cd3bb1643990233.jpg"
                                        class="testimonial-img" alt="">
                                </div>
                                <h3 class="title">— Sarah M., UK</h3>
                                
                            </div>

                        </div>
                    </div> -->
                    <div class="single-slide">
                        <div class="testimonial-box">
                            <div class="content">
                                <p>
                                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                   “I was new to cryptocurrency, but <?= $company_name ?> made it simple. The tools are intuitive and helped me understand my investments better.”
                                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                </p>
                            </div>
                            <div class="client">
                                <div class="thumb">
                                    <img src="asset/theme1/images/testimonial/61fd4de828e951643990504.jpg"
                                        class="testimonial-img" alt="">
                                </div>
                                <h3 class="title">— Amina K., Canada</h3>
                                <!-- <span class="designation">Store Owner</span> -->
                            </div>

                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="testimonial-box">
                            <div class="content">
                                <p>
                                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                    “Finally, a platform that’s honest about fees and offers real-time insights. I feel confident knowing my money is in safe hands with <?= $company_name ?>.”
                                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                </p>
                            </div>
                            <div class="client">
                                <div class="thumb">
                                    <img src="asset/theme1/images/testimonial/61fd4e4f859dd1643990607.jpg"
                                        class="testimonial-img" alt="">
                                </div>
                                <h3 class="title">—Daniel  R., UAE</h3>
                                <!-- <span class="designation">Freelancer</span> -->
                            </div>

                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="testimonial-box">
                            <div class="content">
                                <p>
                                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                    “From account setup to withdrawals, everything works smoothly. I recommend <?= $company_name ?> to anyone looking for a trusted crypto and asset management platform.”
                                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                </p>
                            </div>
                            <div class="client">
                                <div class="thumb">
                                    <img src="asset/theme1/images/testimonial/6253da0b3e71e1649662475.jpg"
                                        class="testimonial-img" alt="">
                                </div>
                                <h3 class="title">— Luis G., Brazil</h3>
                                <!-- <span class="designation">Freelancer</span> -->
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="s-pt-100 s-pb-100">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">3 Steps Referral Program</h2>
                        </div>
                    </div>
                </div>
                <div class="referral-wrapper">
                    <div class="referral-box">
                        <span class="referral-box-step">1</span>
                        <span class="caption">Commission</span>
                        <h3 class="referral-box-percentage">5%</h3>
                    </div>
                    <div class="referral-box">
                        <span class="referral-box-step">2</span>
                        <span class="caption">Commission</span>
                        <h3 class="referral-box-percentage">3%</h3>
                    </div>
                    <div class="referral-box">
                        <span class="referral-box-step">3</span>
                        <span class="caption">Commission</span>
                        <h3 class="referral-box-percentage">1%</h3>
                    </div>

                </div>
            </div>
        </section>
        <section class="s-pt-100 s-pb-100 section-bg">

            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">Recent Blog</h2>
                        </div>
                    </div>
                </div>
                <div class="row gy-4">
                    <div class="col-md-6 col-lg-4">
                        <div class="blog-box">
                            <div class="blog-box-thumb">
                                <img src="asset/theme1/images/blog/624d61e797df71649238503.jpg" alt="image">
                            </div>
                            <div class="blog-box-content">
                                <!-- <span class="blog-category">Bitcoin</span> -->
                                <h3 class="title"><a href="blog_1.php">
                                    Major Funding Secured: <?= $company_name ?> Raises $10 Million in Series A Round
                                    </a>
                                </h3>
                                <ul class="blog-meta">
                                    <li><i class="fas fa-clock"></i> 2 months ago</li>
                                    <li><i class="fas fa-comment"></i> 569 Comments</li>
                                </ul>
                                <p class="mb-0 mt-3">
                                    This strategic funding round, led by prominent global investors, will accelerate our product development, enhance platform security, and support our mission to bring smarter investing solutions to users around the world.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="blog-box">
                            <div class="blog-box-thumb">
                                <img src="asset/theme1/images/blog/624d62471f5b51649238599.jpg" alt="image">
                            </div>
                            <div class="blog-box-content">
                                <!-- <span class="blog-category">Crypto</span> -->
                                <h3 class="title"><a href="blog_2.php">
                                    Introducing Multi-Asset Support on <?= $company_name ?>
                                    </a>
                                </h3>
                                <ul class="blog-meta">
                                    <li><i class="fas fa-clock"></i> 3 months ago</li>
                                    <li><i class="fas fa-comment"></i> 456 Comments</li>
                                </ul>
                                <p class="mb-0 mt-3">
                                    Our platform now allows users to manage cryptocurrencies, stocks, and other digital assets in one seamless interface — simplifying portfolio management and maximizing convenience like never before.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="blog-box">
                            <div class="blog-box-thumb">
                                <img src="asset/theme1/images/blog/624d626242e021649238626.jpg" alt="image">
                            </div>
                            <div class="blog-box-content">
                                <!-- <span class="blog-category">Coinbase</span> -->
                                <h3 class="title"><a href="blog_3.php">
                                    <?= $company_name ?> Launches New Risk Management Dashboard
                                   </a>
                                </h3>
                                <ul class="blog-meta">
                                    <li><i class="fas fa-clock"></i> 4 months ago</li>
                                    <li><i class="fas fa-comment"></i> 568 Comments</li>
                                </ul>
                                <p class="mb-0 mt-3">
                                    Designed to help users make smarter decisions, the new dashboard offers real-time market analytics, automated alerts, and customizable risk profiles for better control and transparency in every investment.
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </section>
        <section class="subscribe-section">
            <div class="subscribe-el">
                <img src="asset/theme1/images/elements/paper-plane.png" alt="image">
            </div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">Our Newsletter</h2>
                            <p>Leveraging On The Latest Artificial Intelligence Robots, Our Team Of Expert Traders With
                                Over 15 Years Of Experience Trading Financial Markets. We Ensure A Consistent Returns On
                                Investments Have A Great Investing Experience</p>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-7">
                        <form class="subscribe-form" id="subscribe" method="POST">
                            <input type="hidden" name="_token" value="Uh03H5wcscZvULvvY2s5dmwfC24b9Rz1Tie3M2t3"> <input
                                type="text" name="email" class="form-control subscribe-email"
                                placeholder="Enter Email Here">
                            <button>Subscribe <i class="fas fa-paper-plane"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </section>


        <div class="modal fade" id="calculationModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content bg-dark text-white">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Profit Calculate</h5>
                        <button type="button" class="close btn btn-warning" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true" class="text-light">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body" id="profit">


                    </div>
                </div>
            </div>


    </main>

    <script type="text/javascript">
        var listCountries = ['South Africa', 'USA', 'Germany', 'France', 'Italy', 'South Africa', 'Australia', 'South Africa', 'Canada', 'Argentina', 'Saudi Arabia', 'Mexico', 'South Africa', 'South Africa', 'Venezuela', 'South Africa', 'Sweden', 'South Africa', 'South Africa', 'Italy', 'South Africa', 'United Kingdom', 'South Africa', 'Greece', 'Cuba', 'South Africa', 'Portugal', 'Austria', 'South Africa', 'Panama', 'South Africa', 'South Africa', 'Netherlands', 'Switzerland', 'Belgium', 'Israel', 'Cyprus'];
        var listPlans = ['$500', '$1,500', '$1,000', '$10,000', '$2,000', '$3,000', '$4,000', '$600', '$700', '$2,500'];
        var transarray = ['just <b>invested</b>', 'has <b>withdrawn</b>', 'is <b>trading with</b>'];
        interval = Math.floor(Math.random() * (40000 - 8000 + 1) + 8000);
        var run = setInterval(request, interval);

        function request() {
            clearInterval(run);
            interval = Math.floor(Math.random() * (40000 - 8000 + 1) + 8000);
            var country = listCountries[Math.floor(Math.random() * listCountries.length)];
            var transtype = transarray[Math.floor(Math.random() * transarray.length)];
            var plan = listPlans[Math.floor(Math.random() * listPlans.length)];
            var msg = 'Someone from <b>' + country + '</b> ' + transtype + ' <a href="javascript:void(0);" onclick="javascript:void(0);">' + plan + '</a>';
            $(".mgm .txt").html(msg);
            $(".mgm").stop(true).fadeIn(300);
            window.setTimeout(function () {
                $(".mgm").stop(true).fadeOut(300);
            }, 10000);
            run = setInterval(request, interval);
        }
    </script>

    <!-- Smartsupp Live Chat script -->
    <?php
    require "footer.php";
    ?>
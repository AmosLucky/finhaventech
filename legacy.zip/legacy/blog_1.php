<?php

require "header.php";

?>
   
   <main id="main" class="main-img">

            <section class="breadcrumbs" style="background-image: url(asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center text-capitalize">
                <h2>Recent Blog</h2>
                <ol>
                    <li><a href="index">Home</a></li>
                    <li>Recent Blog</li>
                </ol>
            </div>

        </div>
    </section>

    <!-- ======= Portfolio Section ======= -->
    <section class="s-pt-100 s-pb-100">
        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-8">
                    <div class="card bg-second">
                        <img src="asset/theme1/images/blog/624d61e797df71649238503.jpg" height="400px" width="100%" alt="blog">

                        <div class="p-3">
                            <h3 class="mt-3"><b>
                                
                                    Major Funding Secured: Introducing  Raises $10 Million in Series A Round
                                    
                            </b></h3>
                            <p class="text-justifys"> <p><span style="font-size:16px;">
                               <?= $company_name ?> is proud to announce a significant milestone in its journey — the successful closure of a major funding round. This investment marks a pivotal moment for the company, enabling it to accelerate growth, expand its team, and push forward with innovative product development.
The funding, secured from a group of prominent investors including [insert any notable VC names or angel investors if known], reflects strong market confidence in <?= $company_name ?>'s vision, leadership, and trajectory. It will be instrumental in scaling operations, enhancing customer experience, and entering new markets.
                            </span><br></p>     
                        <p>
                            "Securing this funding is a major endorsement of the work we've done and the ambitious goals we’ve set," said the company. "We’re excited to take <?= $company_name ?> to the next level and continue delivering exceptional value to our customers and partners."

Founded in [Year], <?= $company_name ?> has rapidly gained recognition for its [insert short description of company’s product/service/mission]. With this new capital injection, the company is well-positioned to solidify its place as a leader in [industry/sector].

More details about the funding round and what it means for the future of <?= $company_name ?> will be shared in the coming weeks.
                        </p>                       </p>
                        </div>

                        <div class="social-links my-3 ms-3">
                            <h5 class="d-inline me-2">Share:</h5>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=https://beacon-empower.com/blog/39/facere-asperiores-odio-id-porro" target="_blank"
                                class="social-links-btn btn-border btn-sm ">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="https://www.twitter.com/intent/tweet?text=blog;url=https://beacon-empower.com/blog/39/facere-asperiores-odio-id-porro"
                                target="_blank" class="social-links-btn btn-border btn-sm"><i
                                    class="bx bxl-twitter"></i></a>
                        </div>
                    </div>

                    <div class="mt-5">
                        <h3>All Comments</h3>
                        <hr>
                                                   
                        
                        


                    </div>

                                    </div>
                <div class="col-lg-4 ps-lg-5">
                    <div class="card bg-second">
                        <div class="card-header">
                            <h4 class="mb-0">Recent Blogs</h4>
                        </div>
                        <div class="card-body">
                            <div class="side-blog-list">
                                                                    <div class="side-blog">
                                        <div class="side-blog-thumb">
                                            <img src="asset/theme1/images/blog/624d61e797df71649238503.jpg" alt="image">
                                        </div>
                                        <div class="side-blog-content">
                                            <h6 class="mb-0"><a
                                                    href="blog_1.php">
                                    Major Funding Secured: Introducing  Raises $10 Million in Series A Round
                                    </a>
                                            </h6>
                                        </div>
                                    </div>
                                                                    <div class="side-blog">
                                        <div class="side-blog-thumb">
                                            <img src="asset/theme1/images/blog/624d62471f5b51649238599.jpg" alt="image">
                                        </div>
                                        <div class="side-blog-content">
                                            <h6 class="mb-0"><a
                                                    href="blog_2.php">
                                                   
                                    Introducing Multi-Asset Support on Introducing                                     
                                                </a>
                                            </h6>
                                        </div>
                                    </div>
                                                                    <div class="side-blog">
                                        <div class="side-blog-thumb">
                                            <img src="asset/theme1/images/blog/624d626242e021649238626.jpg" alt="image">
                                        </div>
                                        <div class="side-blog-content">
                                            <h6 class="mb-0"><a
                                                    href="blog_3.php">
                                                   
                                    Introducing  Launches New Risk Management Dashboard
                                   
                                                </a>
                                            </h6>
                                        </div>
                                    </div>
                                                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End Portfolio Section -->

    </main>
<?php

require "footer.php";

?>
<?php
require "conn.php";
?>

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from beacon-empower.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 18 May 2025 10:10:35 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="Uh03H5wcscZvULvvY2s5dmwfC24b9Rz1Tie3M2t3">

    <link rel="shortcut icon" type="image/png" href="asset/theme1/images/icon/icon.png">

    <title>
        <?php

        echo $company_name

        ?>
    </title>
    <link rel="stylesheet" href="asset/theme1/frontend/css/cookie.css">
    <link href="asset/theme1/frontend/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="asset/theme1/frontend/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="asset/theme1/frontend/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="asset/theme1/frontend/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="asset/theme1/frontend/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="asset/theme1/frontend/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="asset/theme1/frontend/css/selectric.css">
    <link rel="stylesheet" href="asset/theme1/frontend/css/animate.min.css">
    <link rel="stylesheet" href="asset/theme1/frontend/css/slick.css">
    <link rel="stylesheet" href="asset/theme1/frontend/css/font-awsome.min.css">
    <link rel="stylesheet" href="asset/theme1/frontend/css/iziToast.min.css">
    <link href="asset/theme1/frontend/css/style.css" rel="stylesheet">


    <style>
        #profit-table tr td {
            color: #fff;
        }
    </style>




    <link rel="stylesheet" href="asset/theme1/frontend/css/color6007.css?primary_color=F7931A">
    <!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '41ed943578728fced9d23583c52c84f7aa6f644e';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>
</head>


<body class="text-capitalize">



    <div class="js-cookie-consent cookie-consent cookie-modal" style="z-index:-1">

        <div class="cookies-card__icon">
            <i class="fas fa-cookie-bite"></i>
        </div>

        <span class="cookie-consent__message">
            Accept Cookie For This Site
        </span>

        <button class="js-cookie-consent-agree cookie-consent__agree btn">
            Accept Cookie
        </button>


    </div>






    <script>
        'use strict'

        window.laravelCookieConsent = (function () {

            const COOKIE_VALUE = 1;
            const COOKIE_DOMAIN = 'beacon-empower.com';

            function consentWithCookies() {
                setCookie('laravel_cookie_consent', COOKIE_VALUE, 7300);
                hideCookieDialog();
            }

            function cookieExists(name) {
                return (document.cookie.split('; ').indexOf(name + '=' + COOKIE_VALUE) !== -1);
            }

            function hideCookieDialog() {
                const dialogs = document.getElementsByClassName('js-cookie-consent');

                for (let i = 0; i < dialogs.length; ++i) {
                    dialogs[i].style.display = 'none';
                }
            }

            function setCookie(name, value, expirationInDays) {
                const date = new Date();
                date.setTime(date.getTime() + (expirationInDays * 24 * 60 * 60 * 1000));
                document.cookie = name + '=' + value
                    + ';expires=' + date.toUTCString()
                    + ';domain=' + COOKIE_DOMAIN
                    + ';path=/'
                    + ';samesite=lax';
            }

            if (cookieExists('laravel_cookie_consent')) {
                hideCookieDialog();
            }

            const buttons = document.getElementsByClassName('js-cookie-consent-agree');

            for (let i = 0; i < buttons.length; ++i) {
                buttons[i].addEventListener('click', consentWithCookies);
            }

            return {
                consentWithCookies: consentWithCookies,
                hideCookieDialog: hideCookieDialog
            };
        })();
    </script>






    <header id="header" class="fixed-top ">
        <div class="container d-flex align-items-center justify-content-lg-between">

            <div class="logo me-auto me-lg-0"><a href="index.html">
                    <span>

                        <img class="img-fluid rounded sm-device-img text-align" src="asset/theme1/images/logo/logo.png"
                            width="100%" alt="pp">

                    </span>
                </a>
            </div>
            <nav id="navbar" class="navbar order-last order-lg-0">
                <ul>
                    <li class="active"><a class="nav-link" href="index">Home</a></li>
                    <li><a class="nav-link" href="plan">Investment Plans</a>
                    </li>

                    <li><a class="nav-link" href="about">About</a>
                    </li>
                    <li><a class="nav-link" href="contact">Contact</a>
                    </li>
                    <li><a class="nav-link" href="blogs">Blog</a></li>



                    <li class="d-md-block d-lg-none d-block ">
                        <a class="nav-link" href="login">Login</a>
                    </li>

                     <li class="d-md-block d-lg-non d-block ">
                        <a class="nav-link" href="register">Register</a>
                    </li>


                    <li class=" d-sm-block d-md-block d-lg-none">
                        <select class="custom-select-form selectric ms-3 rounded changeLang nav-link scrollto"
                            aria-label="Default select example">
                            <option value="english">
                                Eng
                            </option>
                            <option value="spanish">
                                Spanish
                            </option>
                            <option value="EN">
                                English
                            </option>
                        </select>
                    </li>



                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav>
            <div class="header-right d-flex d-none  d-md-none d-lg-block">
                <a href="login" class="btn-border btn-sm me-3">Login</a>
                <select class="changeLang" aria-label="Default select example">
                    <option value="english">
                        Eng
                    </option>
                    <option value="spanish">
                        Spanish
                    </option>
                    <option value="EN">
                        English
                    </option>
                </select>
            </div>
        </div>
    </header>
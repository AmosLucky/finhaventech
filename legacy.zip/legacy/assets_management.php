<?php

require "header.php";

?>
    <main id="main" class="main-img">

            <section class="breadcrumbs" style="background-image: url(../asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center text-capitalize">
                <h2>Our Service</h2>
                <ol>
                    <li><a href="index">Home</a></li>
                    <li>Our Service</li>
                </ol>
            </div>

        </div>
    </section>

    <!-- ======= Portfolio Section ======= -->
    <section class="s-pt-100 s-pb-100">
        <div class="container">

            <div class="col-md-12">
                <div class="row ">
                    <div class="col-md-12">
                        <div class="card bg-second">
                            <div class="invest-top">
                                <h4 class="text-center"><b>Asset Management</b></h4>
                            </div>
                            <div class="p-3">
                                 <h3>Asset Management: Maximizing Value, Minimizing Risk</h3>
                                
                                <p>
                                    At <?= $company_name ?>, we offer comprehensive Asset Management solutions designed to protect, grow, and optimize your wealth. In an increasingly complex economic environment, managing assets requires more than passive oversight—it demands active strategy, deep market insight, and risk-conscious decision-making. Whether your portfolio includes digital assets, real estate, business equity, or a combination of holdings, our team is equipped to help you navigate the path to financial security and growth.
                                </p>
                                <h3>Our Approach to Asset Management</h3>
                                <p>
                                    Our philosophy is built on three key pillars: preservation, performance, and transparency. We work closely with each client to create a customized strategy that aligns with their unique financial objectives, risk tolerance, and time horizon. Through ongoing analysis, strategic diversification, and proactive risk management, we ensure that every asset under our care is working to its full potential.
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section><!-- End Portfolio Section -->

    </main>

    <?php

    require "footer.php";

    ?>
<?php

require "header.php";

?>
    <main id="main" class="main-img">

        <!-- ======= Breadcrumbs ======= -->
        <section class="breadcrumbs" style="background-image: url(asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
            <div class="container">
                <div class="d-flex justify-content-between align-items-center text-capitalize">
                    <h2>About</h2>
                    <ol>
                        <li><a href="index.html">Home</a></li>
                        <li>About</li>
                    </ol>
                </div>

            </div>
        </section>
        <!-- End Breadcrumbs -->

        <section class="about-section s-pt-100 s-pb-100 section-bg">
            <div class="shape-el">
                <img src="asset/theme1/images/about/flow-chart.png" alt="image">
            </div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-thumb">
                            <div class="about-thumb-inner">
                                <img src="asset/theme1/images/about/6257a3187a4ca1649910552.png" alt="image">
                                <div class="about-thumb-line about-thumb-line-one"></div>
                                <div class="about-thumb-line about-thumb-line-two"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <h2 class="section-title">About Us</h2>
                        <p class="text-white text-justifys descripton-root">
                        <p style="font-size:16px;font-family:Rubik, sans-serif;">
                            <?= $company_name ?> is a premier technology-driven platform at the forefront of cryptocurrency, asset management, and risk management services. Founded on the principles of transparency, security, and innovation, <?= $company_name ?> has become a trusted destination for individuals and organizations seeking reliable solutions in the digital investment space.
                        </p>
                        <p style="font-size:16px;font-family:Rubik, sans-serif;">
                            "Securing this funding is a major endorsement of the work we've done and the ambitious goals we’ve set," said the company. "We’re excited to take <?= $company_name ?> to the next level and continue delivering exceptional value to our customers and partners."
                        </p>
                        <p style="font-size:16px;font-family:Rubik, sans-serif;">
                           Founded in 2021, <?= $company_name ?> has rapidly gained recognition for its innovative solutions that leverage technology to simplify complex problems and deliver seamless digital experiences across industries. Whether through its intuitive platform, user-focused products, or commitment to customer success, the company continues to drive positive change in the tech landscape.
                        </p>
                        <p style="font-size:16px;font-family:Rubik, sans-serif;">We value privacy and security. You will
                            never need to send your personal information to us. Everyone should have the opportunity to
                            enter the Bitcoin world. After all, Bitcoin is a borderless technology. Traders identify
                            each other if they want or need. Traders determine the rules of each trade themselves.</p>
                        <span style="font-family:Rubik, sans-serif;font-size:16px;">We try to learn from our users and
                            other competitors. We love your feedback. Just</span><span
                            style="font-family:Rubik, sans-serif;font-size:16px;"> </span><a
                            href="contact">write us</a><span
                            style="font-family:Rubik, sans-serif;font-size:16px;"> </span><span
                            style="font-family:Rubik, sans-serif;font-size:16px;">a line, we read all your
                            feedback.</span><span
                            style="color:rgb(0,0,0);font-family:'Open Sans', Arial, sans-serif;font-size:14px;text-align:justify;">.</span>
                        </p>
                        <a href="about" class="cmn-btn">Learn More</a>
                    </div>
                </div>

            </div>
        </section>
         <section class="s-pt-100 s-pb-100 section-bg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">FAQ</h2>
                        </div>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-1">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse1" aria-expanded="false" aria-controls="collapseSix">
                                       Is <?= $company_name ?> a Registered Company?
                                    </button>
                                </h2>
                                <div id="collapse1" class="accordion-collapse collapse" aria-labelledby="heading-1"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            Yes, <?= $company_name ?> is a fully registered and compliant company, operating under the legal regulations of the jurisdictions we serve. Your trust and security are our top priorities.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-2">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapseSix">
                                        How Do I Create an Account?
                                    </button>
                                </h2>
                                <div id="collapse2" class="accordion-collapse collapse" aria-labelledby="heading-2"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            Creating an account is simple. Click the “Sign Up” button, provide your basic details, verify your email, and complete identity verification to get started.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-3">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse3" aria-expanded="false" aria-controls="collapseSix">
                                        What Payment Methods Are Supported?
                                    </button>
                                </h2>
                                <div id="collapse3" class="accordion-collapse collapse" aria-labelledby="heading-3"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            We support a variety of payment methods including bank transfers, credit/debit cards, and selected cryptocurrencies for deposits and withdrawals.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-4">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse4" aria-expanded="false" aria-controls="collapseSix">
                                        Is My Information and Investment Safe?
                                    </button>
                                </h2>
                                <div id="collapse4" class="accordion-collapse collapse" aria-labelledby="heading-4"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            Absolutely. <?= $company_name ?> uses advanced encryption, two-factor authentication, and secure servers to protect your personal and financial information.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-5">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse5" aria-expanded="false" aria-controls="collapseSix">
                                        Can I Withdraw My Funds Anytime?
                                    </button>
                                </h2>
                                <div id="collapse5" class="accordion-collapse collapse" aria-labelledby="heading-5"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            Yes, you can request withdrawals at any time. We process most withdrawal requests quickly and securely, depending on the payment method chosen.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion" id="accordionExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-6">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse6" aria-expanded="false" aria-controls="collapseSix">
                                        Do I Need Experience to Use <?= $company_name ?>?
                                    </button>
                                </h2>
                                <div id="collapse6" class="accordion-collapse collapse" aria-labelledby="heading-6"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p> 
                                            No prior experience is needed. Our platform is designed for both beginners and professionals, offering user-friendly tools and 24/7 customer support to guide you.


                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
         <section class="s-pt-100 s-pb-100 section-bg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">What Our Clients Say</h2>
                        </div>
                    </div>
                </div>

                <div class="testimonial-slider">
                    <!-- <div class="single-slide">
                        <div class="testimonial-box">
                            <div class="content">
                                <p>
                                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                   “<?= $company_name ?> has completely changed how I manage my digital assets. The platform is secure, easy to use, and their support team is always there when I need help.”
                                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                </p>
                            </div>
                            <div class="client">
                                <div class="thumb">
                                    <img src="asset/theme1/images/testimonial/61fd4cd9cd3bb1643990233.jpg"
                                        class="testimonial-img" alt="">
                                </div>
                                <h3 class="title">— Sarah M., UK</h3>
                                
                            </div>

                        </div>
                    </div> -->
                    <div class="single-slide">
                        <div class="testimonial-box">
                            <div class="content">
                                <p>
                                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                   “I was new to cryptocurrency, but <?= $company_name ?> made it simple. The tools are intuitive and helped me understand my investments better.”
                                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                </p>
                            </div>
                            <div class="client">
                                <div class="thumb">
                                    <img src="asset/theme1/images/testimonial/61fd4de828e951643990504.jpg"
                                        class="testimonial-img" alt="">
                                </div>
                                <h3 class="title">— Amina K., Canada</h3>
                                <!-- <span class="designation">Store Owner</span> -->
                            </div>

                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="testimonial-box">
                            <div class="content">
                                <p>
                                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                    “Finally, a platform that’s honest about fees and offers real-time insights. I feel confident knowing my money is in safe hands with <?= $company_name ?>.”
                                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                </p>
                            </div>
                            <div class="client">
                                <div class="thumb">
                                    <img src="asset/theme1/images/testimonial/61fd4e4f859dd1643990607.jpg"
                                        class="testimonial-img" alt="">
                                </div>
                                <h3 class="title">—Daniel  R., UAE</h3>
                                <!-- <span class="designation">Freelancer</span> -->
                            </div>

                        </div>
                    </div>
                    <div class="single-slide">
                        <div class="testimonial-box">
                            <div class="content">
                                <p>
                                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                    “From account setup to withdrawals, everything works smoothly. I recommend <?= $company_name ?> to anyone looking for a trusted crypto and asset management platform.”
                                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                </p>
                            </div>
                            <div class="client">
                                <div class="thumb">
                                    <img src="asset/theme1/images/testimonial/6253da0b3e71e1649662475.jpg"
                                        class="testimonial-img" alt="">
                                </div>
                                <h3 class="title">— Luis G., Brazil</h3>
                                <!-- <span class="designation">Freelancer</span> -->
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="subscribe-section">
            <div class="subscribe-el">
                <img src="asset/theme1/images/elements/paper-plane.png" alt="image">
            </div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="section-top">
                            <h2 class="section-title">Our Newsletter</h2>
                            <p>Leveraging On The Latest Artificial Intelligence Robots, Our Team Of Expert Traders With
                                Over 15 Years Of Experience Trading Financial Markets. We Ensure A Consistent Returns On
                                Investments Have A Great Investing Experience</p>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-7">
                        <form class="subscribe-form" id="subscribe" method="POST">
                            <input type="hidden" name="_token" value="Uh03H5wcscZvULvvY2s5dmwfC24b9Rz1Tie3M2t3"> <input
                                type="text" name="email" class="form-control subscribe-email"
                                placeholder="Enter Email Here">
                            <button>Subscribe <i class="fas fa-paper-plane"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </section>




    </main>

    <?php

    require "footer.php";


?>
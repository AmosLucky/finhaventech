<?php

require "header.php";


?>
<main id="main" class="main-img">

    <section class="breadcrumbs" style="background-image: url(asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center text-capitalize">
                <h2>Investment Plan</h2>
                <ol>
                    <li><a href="index.html">Home</a></li>
                    <li>Investment Plan</li>
                </ol>
            </div>
        </div>
    </section>


    <section class="s-pt-100 s-pb-100">
        <div class="container">
             <div class="row gy-4">

                   <?php

                                           $sql = "SELECT * from investment_plans where deleted = '0' order by id desc ";
                                    $sn = 1;
                                   $result = mysqli_query($con,$sql) or die("cant select members ".mysqli_error($con));
                                   while ($row = mysqli_fetch_array($result)) {
                                      $id = $row['id'];
              $min =  $row['min_deposite'];
               $max =  $row['max_deposite'];
               $profit =  $row['daily_profit'];
                $name =  $row['name'];
                $capital_after =  $row['capital_after'];
                 $profit_after =  $row['profit_after'];
                 $referal_bonus =  $row['referal_bonus'];
                  $reg_date =  $row['reg_date'];
                  $daily_profit =  $row['daily_profit'];

                                            ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="invest-plan">
                            <div class="invest-plan-shape"></div>
                            <div class="invest-plan-top">
                                <h4 class="invest-plan-name"><?= $name ?></h4>
                                <h5 class="invest-plan-amount"><?= $daily_profit ?>% daily
                                </h5>
                                <p class="mb-0">After 24hours</p>
                            </div>

                            <div class="invest-plan-middle">
                                <h5 class="invest-plan-min-max">
                                    Min
                                   <?= number_format($min) ?> USD
                                    <p class="mb-0">-</p>
                                    Max
                                     <?php if($max == "UNLIMITED"){
                                        echo $max;
                                    }else{ 
                                       echo number_format($max);
                                    }  ?> USD
                                </h5>
                                <ul class="invest-plan-features">
                                    <li>
                                        Daily Profit: <?= $daily_profit ?>%

                                    </li>
                                     <li>
                                       Referral Bonus: <?= $referal_bonus ?>%

                                    </li>
                                     <li>
                                        Duration: 24Hour(s)

                                    </li>



                                    <li>Capital Back YES</li>
                                </ul>
                            </div>
                            <div class="invest-plan-action mt-3">
                                <a class="cmn-btn w-100 mb-3" href="login">Invest Now</a>


                            </div>
                        </div>
                    </div>

                    <?php } ?>


                    
                    
                    
                   
                </div>
        </div>
    </section>
               

</main>

<?php


require "footer.php";


?>
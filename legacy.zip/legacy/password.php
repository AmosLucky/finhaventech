<?php
require "header.php";

?>
    

        <main id="main" class="main-img">

            
            <section class="auth-section">
            <div class="auth-wrapper">
                <div style="height:200px"></div>
                <!-- <div class="auth-top-part">
                    <a href="../index.html" class="auth-logo w-100 text-center">
                        <img class="img-fluid rounded sm-device-img text-align" src="../asset/theme1/images/logo/logo.png" width="100%" alt="logo">
                    </a>
                </div> -->
            <div class="auth-body-part">
                <div class="auth-form-wrapper">
                    <h3 class="text-center mb-4">Request For Reset Password</h3>
                    <form action="" method="POST">
                        <input type="hidden" name="_token" value="Uh03H5wcscZvULvvY2s5dmwfC24b9Rz1Tie3M2t3">                        <div class="mb-3">
                            <label>Email Address <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email" id="email"
                            placeholder="Enter Email">
                        </div>
                                                <div class="mb-3">
                            <button type="submit" id="recaptcha" class="cmn-btn w-100">Send Verification Code</button>
                        </div>
                        <div>
                            <p class="text-center">Login Again? <a href="../login.html" class="color-change" >Login</a></p>
                        </div>
                    </form>
                </div>
            </div>

</div>


</section>
</main>
            <?php

            require "footer.php";

            ?>
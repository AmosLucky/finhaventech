<?php

require "header.php";

?>
    <main id="main" class="main-img">

            <section class="breadcrumbs" style="background-image: url(../asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center text-capitalize">
                <h2>Our Service</h2>
                <ol>
                    <li><a href="index">Home</a></li>
                    <li>Our Service</li>
                </ol>
            </div>

        </div>
    </section>

    <!-- ======= Portfolio Section ======= -->
    <section class="s-pt-100 s-pb-100">
        <div class="container">

            <div class="col-md-12">
                <div class="row ">
                    <div class="col-md-12">
                        <div class="card bg-second">
                            <div class="invest-top">
                                <h4 class="text-center"><b>Digital Asset Recovery</b></h4>
                            </div>
                            <div class="p-3">
                                <h3>Digital Asset Recovery</h3>
                                <p>
                                    At <?= $company_name ?>, we specialize in Digital Asset Recovery, helping individuals, businesses, and institutions reclaim lost, stolen, or inaccessible digital assets. In today’s fast-paced digital economy, the loss of digital assets—whether due to cyberattacks, forgotten credentials, failed transactions, or compromised wallets—can be devastating. Our mission is to bring clarity, security, and resolution to these high-stakes situations.
                                </p>
                                <p>
                                    At <?= $company_name ?>, we bring together a multidisciplinary team of blockchain analysts, cybersecurity experts, legal advisors, and digital forensics specialists. Our approach is both technical and strategic, using the latest tools and methodologies to trace assets across blockchains, investigate transactions, and identify potential avenues for recovery.
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section><!-- End Portfolio Section -->

    </main>

    <?php

    require "footer.php";

    ?>
<?php

require "header.php";

?>
    <main id="main" class="main-img">

            <section class="breadcrumbs" style="background-image: url(../asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center text-capitalize">
                <h2>Our Service</h2>
                <ol>
                    <li><a href="index">Home</a></li>
                    <li>Our Service</li>
                </ol>
            </div>

        </div>
    </section>

    <!-- ======= Portfolio Section ======= -->
    <section class="s-pt-100 s-pb-100">
        <div class="container">

            <div class="col-md-12">
                <div class="row ">
                    <div class="col-md-12">
                        <div class="card bg-second">
                            <div class="invest-top">
                                <h4 class="text-center"><b>Real Estate</b></h4>
                            </div>
                            <div class="p-3">
                                 <h3>Real Estate: Strategic Investment & Management Solutions</h3>
                                <p>
                                    At <?= $company_name ?>, we offer a full spectrum of Real Estate services designed to deliver long-term value, secure capital growth, and support informed property investment decisions. Whether you are an individual investor, an institutional client, or a high-net-worth portfolio holder, our team combines industry expertise with data-driven insights to help you invest in, manage, and scale your real estate assets with confidence.
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section><!-- End Portfolio Section -->

    </main>

    <?php

    require "footer.php";

    ?>
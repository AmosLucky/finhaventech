<?php

require "header.php";

?>

           <div class="content-w">


                <div class="content-i">
                    <div class="content-box">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="element-wrapper">
                                    <div class="element-box">
                                        <center><h2 class="text-danger">Attention!!!</h2>
                                        <p class="alert text-white" role="alert" style="background:#FF0000;">
                                        Dear Valued Customer , your account has been temporarily blocked from Making online transactions due to unusual activity.
                                        <br>
This measure is to ensure the security of your account.
<br>
Please contact our customer service for assistance and to resolve this issue.
<br>
support@blue-ridgetrust.com
<br>
Thank you for banking with us.
<br>
Best regards.
                                       </p>
                                                <a href="./" class="btn btn-primary">EXIT</a></center>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--<div class="floated-chat-btn"><i class="os-icon os-icon-mail-07"></i><span>Chat</span></div>
  <div class="floated-chat-w">
    <div class="floated-chat-i">
      <div class="chat-close"><i class="os-icon os-icon-close"></i></div>
      <div class="chat-head">
        <div class="user-w with-status status-red">
          <div class="user-avatar-w">
            <div class="user-avatar"><img alt="" src="img/avatar1.jpeg"></div>
          </div>
          <div class="user-name">
            <h6 class="user-title">MIKE</h6>
            <div class="user-role">Customer Service</div>
          </div>
        </div>
      </div>
      <div class="chat-messages">
        <div class="message">
          <div class="message-content">Hi Jerry, how can I help you?</div>
        </div>
        <div class="date-break">22nd May 09:02 01am</div>
        <div class="message">
          <div class="message-content">We are currently offline, please drop your message and we will reply you shortly</div>
        </div>
      </div>
      <div class="chat-controls">
        <input class="message-input" placeholder="Type your message here..." type="text">
        <div class="chat-extra"></div>
      </div>
    </div>
  </div>-->
   </div>
                </div>
            </div>
        </div>
      <?php

      require "footer.php";
      
      ?>
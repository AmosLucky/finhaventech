// //preload-container
// $(document).ready(function () {
//     $("#loginBtn").on("click", function (e) {
//         e.preventDefault();
//         $(".preload-container").show();
//         var id = $("#id").val();
//         //    if (id=="") {
//         //     $("#ermptyErrro").html("<i style='color:red'>Id cant be empty</i>");
//         //    }
//         $.ajax({
//             url: "../Authentication/login.php",
//             type: "POST",
//             data: { id: id },

//             beforSend: function () {
//                 $(".preload-container").show();
//             },

//             success: function (data) {
//                 //console.log(data);
//                 if (data == "emptyId") {
//                     $("#ermptyErrro").html("<i style='color:red;input'>Id can't be empty</i>");
//                     return false;
//                 } else {
//                     if (data == "invakidACC") {
//                         swal({
//                             title: "Opps!",
//                             text: "Invalid Account!",
//                             icon: "error",
//                             button: "Ok!",

//                         })
//                     }
//                 }
//                 if (data == "succesdash") {
//                     window.location.href = '../costomer/dashboard.php';
//                 }

//             },

//             complete: function () {
//                 $(".preload-container").hide();
//             }
//         })
//     })
// })
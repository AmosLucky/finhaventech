


  KJE.parameters.set("CLIP_COUPONS",0);
  KJE.parameters.set("DISCONNECT_CABLE_TV",0);
  KJE.parameters.set("EAT_OUT_LESS",0);
  KJE.parameters.set("ELIMINATE_CELL_PHONE",0);
  KJE.parameters.set("FEDERAL_TAX_RATE",25);
  KJE.parameters.set("FEWER_MOVIES",0);
  KJE.parameters.set("FEWER_VACTIONS",0);
  KJE.parameters.set("OTHER_BUDGET",0);
  KJE.parameters.set("OTHER_ENTERTAINMENT",0);
  KJE.parameters.set("OTHER_UTILITY",0);
  KJE.parameters.set("PAYOFF_CREDIT_CARDS",0);
  KJE.parameters.set("RATE_OF_RETURN",KJE.Default.RORSave);
  KJE.parameters.set("REDUCE_LONG_DISTANCE",0);
  KJE.parameters.set("STATE_TAX_RATE",6);
  KJE.parameters.set("WAIT_FOR_NEW_CAR",0);
  KJE.parameters.set("YEARS_OF_SAVING",10);

  
KJE.ReportProcess = function(sText) {
sText= KJE.replace("appraised","assessed value",sText);
sText= KJE.replace("Appraised","Assessed value",sText);
return KJE.replace("value value","value",sText);
}


KJE.parseDefinitions = function(sText) {
sText= KJE.replace("appraised","assessed value",sText);
sText= KJE.replace("Appraised","Assessed value",sText);
return KJE.replace("value value","value",sText);
}
/**V3_CUSTOM_CODE**/
/* <!--
  Financial Calculators, &copy;1998-2022 KJE Computer Solutions, Inc.
  For more information please see:
  <A HREF="https://www.dinkytown.net">https://www.dinkytown.net</A>
 -->
 */






  KJE.parameters.set("CC_BALANCE1",5000);
  KJE.parameters.set("CC_BALANCE10",0);
  KJE.parameters.set("CC_BALANCE2",0);
  KJE.parameters.set("CC_BALANCE3",0);
  KJE.parameters.set("CC_BALANCE4",0);
  KJE.parameters.set("CC_BALANCE5",0);
  KJE.parameters.set("CC_BALANCE6",0);
  KJE.parameters.set("CC_BALANCE7",0);
  KJE.parameters.set("CC_BALANCE8",0);
  KJE.parameters.set("CC_BALANCE9",0);
  KJE.parameters.set("CC_PAYMENT1",178.75);
  KJE.parameters.set("CC_PAYMENT10",0);
  KJE.parameters.set("CC_PAYMENT2",0);
  KJE.parameters.set("CC_PAYMENT3",0);
  KJE.parameters.set("CC_PAYMENT4",0);
  KJE.parameters.set("CC_PAYMENT5",0);
  KJE.parameters.set("CC_PAYMENT6",0);
  KJE.parameters.set("CC_PAYMENT7",0);
  KJE.parameters.set("CC_PAYMENT8",0);
  KJE.parameters.set("CC_PAYMENT9",0);
  KJE.parameters.set("CC_RATE1",18.9);
  KJE.parameters.set("CC_RATE10",0);
  KJE.parameters.set("CC_RATE2",0);
  KJE.parameters.set("CC_RATE3",0);
  KJE.parameters.set("CC_RATE4",0);
  KJE.parameters.set("CC_RATE5",0);
  KJE.parameters.set("CC_RATE6",0);
  KJE.parameters.set("CC_RATE7",0);
  KJE.parameters.set("CC_RATE8",0);
  KJE.parameters.set("CC_RATE9",0);

KJE.ReportProcess = function(sText) {
sText= KJE.replace("appraised","assessed value",sText);
sText= KJE.replace("Appraised","Assessed value",sText);
return KJE.replace("value value","value",sText);
}


KJE.parseDefinitions = function(sText) {
sText= KJE.replace("appraised","assessed value",sText);
sText= KJE.replace("Appraised","Assessed value",sText);
return KJE.replace("value value","value",sText);
}
/**V3_CUSTOM_CODE**/
/* <!--
  Financial Calculators, &copy;1998-2022 KJE Computer Solutions, Inc.
  For more information please see:
  <A HREF="https://www.dinkytown.net">https://www.dinkytown.net</A>
 -->
 */



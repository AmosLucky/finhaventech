


  KJE.parameters.set("ASSET_GROWTH",KJE.Default.RORMarket);
  KJE.parameters.set("AUTOMOBILES",0);
  KJE.parameters.set("AUTO_LOANS",0);
  KJE.parameters.set("BONDS",0);
  KJE.parameters.set("CASH",0);
  KJE.parameters.set("CHECKING_AND_SAVINGS",0);
  KJE.parameters.set("CREDIT_CARD_DEBT",0);
  KJE.parameters.set("DEBT_GROWTH",0);
  KJE.parameters.set("HOME",0);
  KJE.parameters.set("HOME_MORTGAGE_PRINCIPAL",0);
  KJE.parameters.set("HOUSEHOLD_ITEMS",0);
  KJE.parameters.set("JEWELRY",0);
  KJE.parameters.set("LIFE_INSURANCE",0);
  KJE.parameters.set("MUTUAL_FUNDS",0);
  KJE.parameters.set("OTHER",0);
  KJE.parameters.set("OTHER_LOANS",0);
  KJE.parameters.set("OTHER_MORTGAGE_PRINCIPAL",0);
  KJE.parameters.set("OTHER_REAL_ESTATE",0);
  KJE.parameters.set("OTHER_VEHICLES",0);
  KJE.parameters.set("RETIREMENT_ACCOUNTS",0);
  KJE.parameters.set("SAVINGS_BONDS",0);
  KJE.parameters.set("STOCKS",0);
  KJE.parameters.set("STUDENT_LOANS",0);
  KJE.parameters.set("YEARS_TO_PROJECT",10);


KJE.ReportProcess = function(sText) {
sText= KJE.replace("appraised","assessed value",sText);
sText= KJE.replace("Appraised","Assessed value",sText);
return KJE.replace("value value","value",sText);
}


KJE.parseDefinitions = function(sText) {
sText= KJE.replace("appraised","assessed value",sText);
sText= KJE.replace("Appraised","Assessed value",sText);
return KJE.replace("value value","value",sText);
}
/**V3_CUSTOM_CODE**/
/* <!--
  Financial Calculators, &copy;1998-2022 KJE Computer Solutions, Inc.
  For more information please see:
  <A HREF="https://www.dinkytown.net">https://www.dinkytown.net</A>
 -->
 */



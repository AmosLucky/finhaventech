


  KJE.parameters.set("BANKRUPTCY_LAST_TWO_YEARS",0);
  KJE.parameters.set("BANKRUPTCY_THREE_TO_SEVEN_YEARS",0);
  KJE.parameters.set("FORECLOSURE_LAST_TWO_YEARS",0);
  KJE.parameters.set("FORECLOSURE_THREE_TO_SEVEN_YEARS",0);
  KJE.parameters.set("GRAPHCOLOR1","#EB3013");
  KJE.parameters.set("GRAPHCOLOR2","#FFC957");
  KJE.parameters.set("GRAPHCOLOR3","#2BD07E");
  KJE.parameters.set("LOAN_PAYMENTS_30",0);
  KJE.parameters.set("LOAN_PAYMENTS_60",0);
  KJE.parameters.set("LOAN_PAYMENTS_90",0);
  KJE.parameters.set("MORTGAGE_PAYMENTS_30",0);
  KJE.parameters.set("MORTGAGE_PAYMENTS_60",0);
  KJE.parameters.set("MORTGAGE_PAYMENTS_90",0);
  KJE.parameters.set("OPEN_LIEN",0);


KJE.ReportProcess = function(sText) {
sText= KJE.replace("appraised","assessed value",sText);
sText= KJE.replace("Appraised","Assessed value",sText);
return KJE.replace("value value","value",sText);
}


KJE.parseDefinitions = function(sText) {
sText= KJE.replace("appraised","assessed value",sText);
sText= KJE.replace("Appraised","Assessed value",sText);
return KJE.replace("value value","value",sText);
}
/**V3_CUSTOM_CODE**/
/* <!--
  Financial Calculators, &copy;1998-2022 KJE Computer Solutions, Inc.
  For more information please see:
  <A HREF="https://www.dinkytown.net">https://www.dinkytown.net</A>
 -->
 */






  KJE.parameters.set("ALL_OTHER_CHECKS",0.00);
  KJE.parameters.set("ALL_OTHER_DEPOSITS",0.00);
  KJE.parameters.set("BALANCE_ON_STATEMENT",0.00);
  KJE.parameters.set("CHECK_1",0.00);
  KJE.parameters.set("CHECK_10",0.00);
  KJE.parameters.set("CHECK_2",0.00);
  KJE.parameters.set("CHECK_3",0.00);
  KJE.parameters.set("CHECK_4",0.00);
  KJE.parameters.set("CHECK_5",0.00);
  KJE.parameters.set("CHECK_6",0.00);
  KJE.parameters.set("CHECK_7",0.00);
  KJE.parameters.set("CHECK_8",0.00);
  KJE.parameters.set("CHECK_9",0.00);
  KJE.parameters.set("DEPOSIT_1",0.00);
  KJE.parameters.set("DEPOSIT_2",0.00);
  KJE.parameters.set("DEPOSIT_3",0.00);
  KJE.parameters.set("DEPOSIT_4",0.00);
  KJE.parameters.set("DEPOSIT_5",0.00);


KJE.ReportProcess = function(sText) {
sText= KJE.replace("appraised","assessed value",sText);
sText= KJE.replace("Appraised","Assessed value",sText);
return KJE.replace("value value","value",sText);
}


KJE.parseDefinitions = function(sText) {
sText= KJE.replace("appraised","assessed value",sText);
sText= KJE.replace("Appraised","Assessed value",sText);
return KJE.replace("value value","value",sText);
}
/**V3_CUSTOM_CODE**/
/* <!--
  Financial Calculators, &copy;1998-2022 KJE Computer Solutions, Inc.
  For more information please see:
  <A HREF="https://www.dinkytown.net">https://www.dinkytown.net</A>
 -->
 */


